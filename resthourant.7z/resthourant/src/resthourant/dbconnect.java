package resthourant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import resthourant.views.Comanda;
import resthourant.views.Produs;
import resthourant.views.Utilizator;

public class dbconnect {

	/*
	 * static Connection conn = null; private Connection connect = null; private
	 * Statement statement = null; private PreparedStatement preparedStatement =
	 * null; private ResultSet resultSet = null;
	 */

//	 static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
//	 static final String DB_URL = "jdbc:mysql://localhost/restaurant";
//	 static final String USER = "root";
//	 static final String PASS = "serbandeforl100";
	static private Connection conn = null;
	static private PreparedStatement stmt = null;
	static private Statement st = null;
	static private ResultSet rs = null;

	public static Connection ConexiuneBD() {
		try {

			conn = DriverManager.getConnection("jdbc:mariadb://localhost/restdb", "restuser", "123456");
			System.out.println("Conexiune realizata");

//			 Class.forName(JDBC_DRIVER);
//			 System.out.println("Connecting to DB..");
//			 conn = DriverManager.getConnection(DB_URL, USER, PASS);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Conexiune nereusita");
			e.printStackTrace();
		}
		return conn;
	}

	private static void close() {
		close(rs);
		if (st != null)
			close(st);
		if (stmt != null)
			close(stmt);
		close(conn);
	}

	private static void close(AutoCloseable c) throws UnsupportedOperationException {
		try {
			if (c != null) {
				c.close();
			}
		} catch (Exception e) {
		}
	}

	public static List<Produs> getMeniu() {
		List<Produs> listaProduse = new ArrayList<Produs>();
		Connection conn = ConexiuneBD();
		Produs produs = null;
		try {
			String sql = "SELECT id, denumire, cantitate_implicita,pret, tip FROM restaurant.produse";
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				produs = new Produs();
				produs.setId(rs.getInt("id"));
				produs.setDenumire(rs.getString("denumire"));
				produs.setCantitate(rs.getInt("cantitate_implicita"));
				produs.setPret(rs.getInt("pret"));
				produs.setTip(rs.getString("tip"));
				System.out.println(produs);
				listaProduse.add(produs);
			}
			System.out.println("list size = " + listaProduse.size());
		} catch (SQLException e) {
			System.out.println("Failed to create statement. " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement. " + e.getMessage());
			e.printStackTrace();
		} finally {
			close();
		}
		return listaProduse;
	}

	public static Utilizator isUser(String user, String pass) {
		System.out.println("User:" + user);
		System.out.println("Password:" + pass);
		Connection conn = ConexiuneBD();
		Utilizator utilizator = null;
		try {
			String sql = "SELECT id, nume, parola, tip FROM restaurant.utilizatori where nume = ? and parola = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, user);
			stmt.setString(2, pass);
			rs = stmt.executeQuery();
			if (rs.next()) {
				utilizator = new Utilizator();
				utilizator.setId(rs.getInt("id"));
				utilizator.setNume(rs.getString("nume"));
				utilizator.setParola(rs.getString("parola"));
				utilizator.setTip(rs.getString("tip"));
			}
			if ("client".equals(utilizator.getTip())) {
				String sql2 = "SELECT id FROM restaurant.mese where id_utilizator = ?";
				stmt = conn.prepareStatement(sql2);
				stmt.setInt(1, utilizator.getId());
				System.out.println("id util " + utilizator.getId());
				rs = stmt.executeQuery();
				if (rs.next()) {
					System.out.println("intra " + rs.getInt("id"));
					utilizator.setIdMasa(rs.getInt("id"));
				}
				System.out.println("id masa = " + utilizator.getIdMasa());
			}
			System.out.println(utilizator);
		} catch (SQLException e) {
			System.out.println("Failed to create statement. " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement. " + e.getMessage());
			e.printStackTrace();
		} finally {
			close();
		}
		return utilizator;
	}
	
	public static int getId(Connection conn){
		int id = 0;
		try {
			String sql = "SELECT MAX(id) AS id FROM restaurant.comenzi";
			rs = stmt.executeQuery();
			if(rs.next()){
				id = rs.getInt("id");
				System.out.println(id);
			}
		}  catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement");
			e.printStackTrace();
		}
		return id;
	}
	
	public static void insertComanda(Produs produs, int idMasa, Timestamp data) {
		System.out.println("Creating statement..");
		System.out.println("Produs = " + produs);
		System.out.println("idMasa = " + idMasa);
		System.out.println("Date = " + data);
		Connection conn = ConexiuneBD();
		try {
			int id = selectOspatar(conn);
			int nouIdCom = getId(conn);
			String sql = "INSERT INTO restaurant.comenzi(id, id_ospatar, id_produs, id_masa, data, cantitate) VALUES(?, ?, ?, ?, ?, ?)";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, nouIdCom+1);
			stmt.setInt(2, id);
			stmt.setInt(3, produs.getId());
            stmt.setInt(4, idMasa);
            stmt.setTimestamp(5, data);
            stmt.setInt(6, produs.getCantitate());
            int query = stmt.executeUpdate();
            System.out.println(query);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement");
			e.printStackTrace();
		} finally {
			close();
		}
	}

	private static int selectOspatar(Connection conn) {
		int idOspatar = 1;
		List<Integer> listaId = new ArrayList<Integer>();
		try {
			String sql = "SELECT id FROM restaurant.ospatari";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				listaId.add(rs.getInt("id"));
			}
			idOspatar = listaId.get(new Random().nextInt(listaId.size()));
			System.out.println("Id ospatar = " + idOspatar);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement");
			e.printStackTrace();
		}
		return idOspatar;
	}

	public static List<Comanda> getComenzi(int idOspatar) {
		Connection conn = ConexiuneBD();
		List<Comanda> listaComnezi = new ArrayList<Comanda>();
		Comanda comanda = null;
		int id = 0;
		try {
			String sqlid = "SELECT id FROM restaurant.ospatari where id_utilizator = ? ";
			stmt = conn.prepareStatement(sqlid);
			stmt.setInt(1, idOspatar);
			rs = stmt.executeQuery();
			if (rs.next()) {
				id = rs.getInt("id");
			}
			System.out.println("Id ospatar = " + id);
			String sql = "SELECT id, id_masa FROM restaurant.comenzi where id_ospatar = ? and livrat = 0 GROUP BY id_masa";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			while (rs.next()) {
				comanda = new Comanda();
				comanda.setId(rs.getInt("id"));
				comanda.setId_masa(rs.getInt("id_masa"));
				listaComnezi.add(comanda);
			}
			System.out.println("lista size = " + listaComnezi.size());
			for (Comanda com : listaComnezi) {
				String sql2 = "SELECT p.denumire, p.pret*c.cantitate as valoare FROM restaurant.comenzi c, restaurant.produse p WHERE  c.id= ? AND c.id_produs = p.id";
				stmt = conn.prepareStatement(sql2);
				stmt.setInt(1, com.getId_masa());
				List<Produs> listaProduse = new ArrayList<Produs>();
				Produs prod = null;
				rs = stmt.executeQuery();
				while (rs.next()) {
					prod = new Produs();
					prod.setDenumire(rs.getString("p.denumire"));
					prod.setPret(rs.getInt("valoare"));
					System.out.println(prod);
					com.setProduse(listaProduse);
				}
				System.out.println(com);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Failed to create statement");
			e.printStackTrace();
		} finally {
			close();
		}
		return listaComnezi;
	}
}
