package resthourant.views;

import java.sql.Timestamp;
import java.util.List;

public class Comanda {
	private int id;
	private int id_ospatar;
	private int id_produs;
	private int id_masa;
	private Timestamp data;
	private int cantitate;
	private int livrat;
	private List<Produs> produse;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getId_ospatar() {
		return id_ospatar;
	}
	public void setId_ospatar(int id_ospatar) {
		this.id_ospatar = id_ospatar;
	}
	public int getId_produs() {
		return id_produs;
	}
	public void setId_produs(int id_produs) {
		this.id_produs = id_produs;
	}
	public int getId_masa() {
		return id_masa;
	}
	public void setId_masa(int id_masa) {
		this.id_masa = id_masa;
	}
	public Timestamp getData() {
		return data;
	}
	public void setData(Timestamp data) {
		this.data = data;
	}
	public int getCantitate() {
		return cantitate;
	}
	public void setCantitate(int cantitate) {
		this.cantitate = cantitate;
	}
	public int getLivrat() {
		return livrat;
	}
	public void setLivrat(int livrat) {
		this.livrat = livrat;
	}
	public List<Produs> getProduse() {
		return produse;
	}
	public void setProduse(List<Produs> produse) {
		this.produse = produse;
	}
	@Override
	public String toString() {
		return "Comanda [id=" + id + ", id_ospatar=" + id_ospatar + ", id_produs=" + id_produs + ", id_masa=" + id_masa
				+ ", data=" + data + ", cantitate=" + cantitate + ", livrat=" + livrat + ", produse=" + produse + "]";
	}
	
}
