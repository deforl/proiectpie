package resthourant.views;

public class Produs {
	private int id;
	private String denumire;
	private int cantitate;
	private int pret;
	private String tip;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDenumire() {
		return denumire;
	}
	public void setDenumire(String denumire) {
		this.denumire = denumire;
	}
	public int getCantitate() {
		return cantitate;
	}
	public void setCantitate(int cantitate) {
		this.cantitate = cantitate;
	}
	public int getPret() {
		return pret;
	}
	public void setPret(int pret) {
		this.pret = pret;
	}
	public String getTip() {
		return tip;
	}
	public void setTip(String tip) {
		this.tip = tip;
	}
	@Override
	public String toString() {
		return "Produs [id=" + id + ", denumire=" + denumire + ", cantitate=" + cantitate + ", pret=" + pret + ", tip="
				+ tip + "]";
	}
}
