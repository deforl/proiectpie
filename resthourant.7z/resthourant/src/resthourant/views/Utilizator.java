package resthourant.views;

public class Utilizator {
	private int id;
	private String nume;
	private String parola;
	private String tip;
	private int idMasa;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getParola() {
		return parola;
	}
	public void setParola(String parola) {
		this.parola = parola;
	}
	public String getTip() {
		return tip;
	}
	public void setTip(String tip) {
		this.tip = tip;
	}
	
	public int getIdMasa() {
		return idMasa;
	}
	public void setIdMasa(int idMasa) {
		this.idMasa = idMasa;
	}
	@Override
	public String toString() {
		return "Utilizator [id=" + id + ", nume=" + nume + ", parola=" + parola + ", tip=" + tip + ", idMasa=" + idMasa
				+ "]";
	}
	
	
}
