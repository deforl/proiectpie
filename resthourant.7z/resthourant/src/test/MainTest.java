package test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import resthourant.dbconnect;
import resthourant.views.Produs;
import resthourant.views.Utilizator;

public class MainTest {
	public static void main(String[] args) {
		String user = "ms01";
		String pass = "masa01";
		Utilizator utilizator = dbconnect.isUser(user, pass);
		if (utilizator != null && "client".equals(utilizator.getTip())) {
			System.out.println("client");
			dbconnect.getMeniu();
			List<Produs> produse = new ArrayList<Produs>();
			Produs produs = new Produs();
			produs.setId(1);
			produs.setCantitate(1);
			produse.add(produs);
			for (Produs pr : produse) {
				dbconnect.insertComanda(pr, utilizator.getIdMasa(), new Timestamp(new Date().getTime()));
			}
		}
		if (utilizator != null && "ospatar".equals(utilizator.getTip())) {
			System.out.println("Ospatar");
			dbconnect.getComenzi(utilizator.getId());
		}
	}
}
